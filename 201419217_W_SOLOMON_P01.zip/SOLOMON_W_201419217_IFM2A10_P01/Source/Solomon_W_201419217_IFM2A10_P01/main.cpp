#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>

using namespace std;

//structs to store data to/from file
#pragma pack(push)
#pragma pack(1)

struct FounderRecord
{
    char FullName[64];
    int Age;
    char Highqual[64];
};

struct ProductRecord
{
    char Description[64];
    int Price;
    int NumDownloads;
};

struct CompanyRecord
{
    char Name[64];
    int Valuation;
    char Sector[64];
    int NumEmployees;
    FounderRecord *founders;
    ProductRecord *products;

};

#pragma pack(pop)

int main()
{
    //variables to be used throughout code
    int NumFounders = 0;
    int NumProducts = 0;
    int NumCompanies = 0;

    int youngest = 0;
    int totalvalue = 0;
    int expensive = 0;
    int index = 0;

    //inputting info from the user
    cout << "How many companies?" << endl;
    cin >> NumCompanies;

    CompanyRecord companyrec[NumCompanies];

    cout << "COMPANY INFORMATION: " << endl << endl;

    for(int i=0; i < NumCompanies; i++)
    {
    cout << "Name of the company? (NO SPACES)" << endl;
    cin >> companyrec[i].Name;
    cout << "Valuation for the company?" << endl;
    cin >> companyrec[i].Valuation;
    cout << "Sector of operation for the company?" << endl;
    cin >> companyrec[i].Sector;
    cout << "Number of employees for the company?" << endl;
    cin >> companyrec[i].NumEmployees;
    cout << endl << endl;

    //calculating the total valuation of all the companies
    totalvalue += companyrec[i].Valuation;

    cout << "How many founders for " << companyrec[i].Name << "?" << endl;
    cin >> NumFounders;

    companyrec[i].founders = new FounderRecord[NumFounders];

    for(int f = 0; f < NumFounders; f++)
    {
        cout << "FOUNDER INFORMATION: " << endl << endl;
        cout << "Name of founder?" << endl;
        cin >> companyrec[i].founders[f].FullName;
        cout << "Age of founder?" << endl;
        cin >> companyrec[i].founders[f].Age;
        cout << "Highest Qualification of founder?" << endl;
        cin >> companyrec[i].founders[f].Highqual;
    }

    for(int c = 0; c < NumFounders ; c++)
    {
        youngest = companyrec[i].founders[0].Age;
         if(youngest > companyrec[i].founders[c].Age)
        {
            youngest = companyrec[i].founders[c].Age;
        }
    }

    cout << endl << endl;

    cout << "How many products for " << companyrec[i].Name << "?" << endl;
    cin >> NumProducts;

    companyrec[i].products = new ProductRecord[NumProducts];

    for(int p = 0; p < NumProducts; p++)
    {
        cout << "PRODUCT INFORMATION: " << endl << endl;
        cout << "Description of product?" << endl;
        cin >> companyrec[i].products[p].Description;
        cout << "Price of using app?" << endl;
        cin >> companyrec[i].products[p].Price;
        cout << "Number of downloads for the app?" << endl;
        cin >> companyrec[i].products[p].NumDownloads;
    }

    for(int m = 0; m < NumProducts; m++)
    {
        expensive = companyrec[i].products[0].Price;
        if(expensive < companyrec[i].products[m].Price)
        {
            expensive = companyrec[i].products[m].Price;
            index = m;
        }
    }
  }

    //displaying the calcuted information in the console
    cout << "Youngest Founder: " << youngest << endl;
    cout << "Total Valuation For All Companies: " << totalvalue << endl;
    cout << "The Highest Priced App For All Companies Cost: " << expensive << endl;
    cout << endl << endl;

    //variable for the filestream
    fstream WriteToFile;

    //writing the records to file
    WriteToFile.write(reinterpret_cast<char*>(&companyrec), sizeof(companyrec));

    WriteToFile.open("CompanyRecords.txt", ios::out);

    WriteToFile.setf(ios::fixed);
    WriteToFile.precision(3);

    //writing the info to file
    for(int i=0 ; i < NumCompanies ; i++)
    {
        WriteToFile << "COMPANY INFORMATION: " << endl;
        WriteToFile << "Company Name: " << companyrec[i].Name << endl;
        WriteToFile << "Company Valuation: " << companyrec[i].Valuation << endl;
        WriteToFile << "Company Sector: " << companyrec[i].Sector << endl;
        WriteToFile << "Number of Employees For Company: " << companyrec[i].NumEmployees << endl;

        for(int f = 0; f < NumFounders; f++)
        {
            WriteToFile << "FOUNDER INFORMATION: " << endl;
            WriteToFile << "Founder Name: " << companyrec[i].founders[f].FullName << endl;
            WriteToFile << "Founder Age: " << companyrec[i].founders[f].Age << endl;
            WriteToFile << "Founder's Highest Qualification: " << companyrec[i].founders[f].Highqual << endl;
        }

        for(int p = 0; p < NumProducts; p++)
        {
            WriteToFile << "PRODUCT INFORMATION: " << endl;
            WriteToFile << "Product Description:  "<< companyrec[i].products[p].Description << endl;
            WriteToFile << "Product Price: "<< companyrec[i].products[p].Price << endl;
            WriteToFile << "Product's Number of Downloads: "<< companyrec[i].products[p].NumDownloads << endl << endl;
        }

        //saving calculated data to the txt file
        WriteToFile << "Youngest Founder: " << youngest << endl;
        WriteToFile << "Total Valuation For All Companies: " << totalvalue << endl;
        WriteToFile << "The Highest Priced App For All Companies Cost: " << expensive << endl;
        WriteToFile << endl << endl;

        WriteToFile.width(7);
        WriteToFile << endl;
    }

    WriteToFile.close();

    //variable for the filestream
    fstream ReadFromFile;

    //reading from the txt file
    ReadFromFile.open("CompanyRecords.txt", ios::in);
    ReadFromFile.seekg(0, ios::end);

    //calculating the number of records in the file
    int bytes = ReadFromFile.tellg();
    int NumRecords = bytes/sizeof(companyrec);

    //reading and dislpaying from the file
    for(int i =0; i < NumRecords; i++)
    {
        CompanyRecord Temp;

        ReadFromFile.seekg(i * sizeof(CompanyRecord), ios::beg);
        ReadFromFile.read(reinterpret_cast<char*>(&Temp), sizeof(CompanyRecord));

        cout << "Company Name: " << Temp.Name << endl;
        cout << "Company Valuaton: " << Temp.Valuation << endl;
        cout << "Company Sector: " << Temp.Sector << endl;
        cout << "Company's Number of Employees: " << Temp.NumEmployees << endl;
    }

    ReadFromFile.close();

    return 0;
}
